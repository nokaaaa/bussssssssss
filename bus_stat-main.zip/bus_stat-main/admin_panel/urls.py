from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('road/', views.road, name='road'),
    path('tickets/', views.tickets, name='tickets'),
    path('statistics/', views.statistics, name='statistics'),
    path('settings/', views.settings, name='settings'),
    path('route/<int:pk>/', views.RouteDetailView.as_view(), name='route_detail'),
    path('contact/', views.contact, name='contact'),
    path('login/', views.custom_login, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('route/create/', views.create_route, name='create_route'),
    path('route/<int:route_id>/', views.route_detail, name='route_detail'),
    path('route/<int:route_id>/boarding-list/', views.generate_boarding_list, name='boarding_list'),
    path('route/<int:route_id>/book/', views.book_ticket, name='book_ticket'),
    path('ticket/<int:ticket_id>/purchase/', views.purchase_ticket, name='purchase_ticket'),
    path('ticket/<int:ticket_id>/refund/', views.refund_ticket, name='refund_ticket'),
    path('toggle-favorite/<int:route_id>/', views.toggle_favorite, name='toggle_favorite'),
    path('notifications/', views.get_notifications, name='get_notifications'),
    path('notifications/<int:notification_id>/read/', views.mark_notification_read, name='mark_notification_read'),
    path('profile/', views.profile, name='profile'),
] 