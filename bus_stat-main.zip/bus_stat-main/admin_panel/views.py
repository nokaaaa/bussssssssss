from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Q
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from .models import Route, Ticket, FavoriteRoute, Notification, BoardingList
from datetime import datetime, timedelta
from django.db.models import Count, Sum
import pytz
from .forms import RouteForm, CustomAuthenticationForm, CustomUserCreationForm
from django.contrib import messages
from django.contrib.auth import login, authenticate
from django.template.loader import render_to_string
from django.core.mail import send_mail
from django.conf import settings
import json
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import cm
from io import BytesIO

# Create your views here.

class DashboardView(LoginRequiredMixin, ListView):
    model = Route
    template_name = 'dashboard.html'
    context_object_name = 'routes'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['current_time'] = datetime.now().strftime("%d.%m.%Y %H:%M")
        return context

class RouteDetailView(LoginRequiredMixin, DetailView):
    model = Route
    template_name = 'route_detail.html'
    context_object_name = 'route'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['tickets'] = Ticket.objects.filter(route=self.object)
        return context

@login_required
def dashboard(request):
    search_query = request.GET.get('search', '')
    from_city = request.GET.get('from_city', '')
    to_city = request.GET.get('to_city', '')
    date = request.GET.get('date', '')
    sort_by = request.GET.get('sort', 'departure_time')

    routes = Route.objects.filter(departure_time__gte=timezone.now())

    if search_query:
        routes = routes.filter(
            Q(from_city__icontains=search_query) |
            Q(to_city__icontains=search_query) |
            Q(number__icontains=search_query)
        )

    if from_city:
        routes = routes.filter(from_city__icontains=from_city)
    if to_city:
        routes = routes.filter(to_city__icontains=to_city)
    if date:
        routes = routes.filter(departure_time__date=date)

    if sort_by == 'price_asc':
        routes = routes.order_by('price')
    elif sort_by == 'price_desc':
        routes = routes.order_by('-price')
    else:
        routes = routes.order_by('departure_time')

    favorite_routes = []
    if request.user.is_authenticated:
        favorite_routes = Route.objects.filter(favoriteroute__user=request.user)

    distinct_cities = Route.objects.values_list('from_city', 'to_city').distinct()
    from_cities = sorted(set(city[0] for city in distinct_cities))
    to_cities = sorted(set(city[1] for city in distinct_cities))

    context = {
        'routes': routes,
        'favorite_routes': favorite_routes,
        'from_cities': from_cities,
        'to_cities': to_cities,
        'search_query': search_query,
        'from_city': from_city,
        'to_city': to_city,
        'date': date,
        'sort_by': sort_by,
    }
    return render(request, 'admin_panel/dashboard.html', context)

@login_required
def road(request):
    current_date = timezone.now()
    routes = Route.objects.all().order_by('departure_time')
    return render(request, 'road.html', {
        'current_date': current_date,
        'routes': routes
    })

@login_required
def tickets(request):
    current_date = timezone.now()
    return render(request, 'tickets.html', {'current_date': current_date})

@login_required
def statistics(request):
    current_date = timezone.now()
    return render(request, 'statistics.html', {'current_date': current_date})

@login_required
def settings(request):
    current_date = timezone.now()
    return render(request, 'settings.html', {'current_date': current_date})

def contact(request):
    return render(request, 'contact.html')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Регистрация успешно завершена!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'admin_panel/register.html', {'form': form})

def custom_login(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Добро пожаловать, {username}!')
                return redirect('dashboard')
            else:
                messages.error(request, 'Неверное имя пользователя или пароль.')
        else:
            messages.error(request, 'Неверное имя пользователя или пароль.')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'admin_panel/login.html', {'form': form})

@login_required
def profile(request):
    user_tickets = Ticket.objects.filter(user=request.user).order_by('-booking_time')
    favorite_routes = Route.objects.filter(favoriteroute__user=request.user)
    notifications = Notification.objects.filter(user=request.user, is_read=False)
    
    context = {
        'user': request.user,
        'tickets': user_tickets,
        'favorite_routes': favorite_routes,
        'notifications': notifications,
    }
    return render(request, 'admin_panel/profile.html', context)

def create_route(request):
    if request.method == 'POST':
        form = RouteForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Маршрут успешно создан!')
            return redirect('route_list')
    else:
        form = RouteForm()
    return render(request, 'admin_panel/create_route.html', {'form': form})

@login_required
def toggle_favorite(request, route_id):
    route = get_object_or_404(Route, id=route_id)
    favorite, created = FavoriteRoute.objects.get_or_create(user=request.user, route=route)
    
    if not created:
        favorite.delete()
        is_favorite = False
    else:
        is_favorite = True
    
    return JsonResponse({
        'is_favorite': is_favorite,
        'favorite_count': FavoriteRoute.objects.filter(route=route).count()
    })

@login_required
def route_detail(request, route_id):
    route = get_object_or_404(Route, id=route_id)
    
    # Обновляем статус маршрута
    route.update_status()
    
    # Получаем все билеты для данного маршрута
    tickets = Ticket.objects.filter(route=route)
    
    # Создаем список занятых мест
    occupied_seats = [ticket.seat_number for ticket in tickets if ticket.is_purchased]
    
    # Добавляем информацию о длительности поездки
    duration = route.arrival_time - route.departure_time
    hours = duration.seconds // 3600
    minutes = (duration.seconds % 3600) // 60
    route.duration = f"{hours}ч {minutes}мин"
    
    context = {
        'route': route,
        'occupied_seats': occupied_seats,
        'can_book': route.status == 'scheduled' and route.available_seats > 0,
        'can_refund': route.status == 'scheduled'
    }
    
    return render(request, 'admin_panel/route_detail.html', context)

@login_required
def book_ticket(request, route_id):
    if request.method == 'POST':
        route = get_object_or_404(Route, id=route_id)
        data = json.loads(request.body)
        seat_number = data.get('seat_number')
        passenger_data = data.get('passenger_data', {})
        
        # Проверяем, не занято ли место
        if Ticket.objects.filter(route=route, seat_number=seat_number).exists():
            return JsonResponse({
                'status': 'error',
                'message': 'Это место уже занято'
            })
        
        # Создаем бронирование
        ticket = Ticket.objects.create(
            route=route,
            user=request.user,
            seat_number=seat_number,
            status='booked',
            passenger_name=passenger_data.get('name'),
            passenger_phone=passenger_data.get('phone'),
            passenger_document=passenger_data.get('document')
        )
        
        # Обновляем количество свободных мест
        route.available_seats -= 1
        route.save()
        
        # Создаем уведомление
        Notification.objects.create(
            user=request.user,
            ticket=ticket,
            type='booking',
            message=f'Билет успешно забронирован: {route}, место {seat_number}'
        )
        
        return JsonResponse({
            'status': 'success',
            'message': 'Билет успешно забронирован',
            'ticket_id': ticket.id
        })
    
    return JsonResponse({'status': 'error', 'message': 'Метод не поддерживается'})

@login_required
def purchase_ticket(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id, user=request.user)
    
    if request.method == 'POST':
        if ticket.status != 'booked':
            return JsonResponse({
                'status': 'error',
                'message': 'Билет не может быть куплен'
            })
        
        # Обновляем статус билета
        ticket.status = 'purchased'
        ticket.is_purchased = True
        ticket.purchase_time = timezone.now()
        ticket.save()
        
        # Создаем уведомление
        Notification.objects.create(
            user=request.user,
            ticket=ticket,
            type='purchase',
            message=f'Билет успешно куплен: {ticket.route}, место {ticket.seat_number}'
        )
        
        # Отправляем email с билетом
        send_ticket_email(ticket)
        
        return JsonResponse({
            'status': 'success',
            'message': 'Билет успешно куплен'
        })
    
    return JsonResponse({'status': 'error', 'message': 'Метод не поддерживается'})

@login_required
def refund_ticket(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id, user=request.user)
    
    if request.method == 'POST':
        data = json.loads(request.body)
        reason = data.get('reason', '')
        
        if ticket.refund(reason):
            return JsonResponse({
                'status': 'success',
                'message': 'Билет успешно возвращен'
            })
        else:
            return JsonResponse({
                'status': 'error',
                'message': 'Билет не может быть возвращен'
            })
    
    return JsonResponse({'status': 'error', 'message': 'Метод не поддерживается'})

@login_required
def get_notifications(request):
    notifications = Notification.objects.filter(user=request.user, is_read=False)
    return JsonResponse({
        'notifications': [
            {
                'id': n.id,
                'message': n.message,
                'type': n.type,
                'created_at': n.created_at.strftime('%d.%m.%Y %H:%M')
            }
            for n in notifications
        ]
    })

@login_required
def mark_notification_read(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.is_read = True
    notification.save()
    return JsonResponse({'status': 'success'})

@login_required
def generate_boarding_list(request, route_id):
    route = get_object_or_404(Route, id=route_id)
    
    # Получаем все купленные билеты
    tickets = Ticket.objects.filter(
        route=route,
        status='purchased'
    ).order_by('seat_number')
    
    # Создаем PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    
    # Стили
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=16,
        spaceAfter=30,
        alignment=1  # По центру
    )
    
    # Заголовок
    elements.append(Paragraph(f'Посадочная ведомость', title_style))
    elements.append(Paragraph(f'Маршрут № {route.number}', title_style))
    
    # Информация о маршруте
    route_info = [
        [Paragraph('Маршрут:', styles['Normal']), Paragraph(f'{route.from_city} - {route.to_city}', styles['Normal'])],
        [Paragraph('Дата отправления:', styles['Normal']), Paragraph(route.departure_time.strftime('%d.%m.%Y'), styles['Normal'])],
        [Paragraph('Время отправления:', styles['Normal']), Paragraph(route.departure_time.strftime('%H:%M'), styles['Normal'])],
        [Paragraph('Автобус:', styles['Normal']), Paragraph(route.bus_info, styles['Normal'])],
        [Paragraph('Водитель:', styles['Normal']), Paragraph(route.driver_name, styles['Normal'])],
        [Paragraph('Телефон водителя:', styles['Normal']), Paragraph(route.driver_phone, styles['Normal'])]
    ]
    
    route_table = Table(route_info, colWidths=[4*cm, 12*cm])
    route_table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(route_table)
    elements.append(Spacer(1, 20))
    
    # Таблица пассажиров
    data = [[
        '№ места',
        'ФИО пассажира',
        'Документ',
        'Телефон',
        'Статус'
    ]]
    
    for ticket in tickets:
        data.append([
            str(ticket.seat_number),
            ticket.passenger_name,
            ticket.passenger_document,
            ticket.passenger_phone,
            ticket.get_status_display()
        ])
    
    table = Table(data, colWidths=[2*cm, 6*cm, 4*cm, 4*cm, 3*cm])
    table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.white),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(table)
    
    # Итоговая информация
    elements.append(Spacer(1, 20))
    elements.append(Paragraph(f'Всего пассажиров: {tickets.count()}', styles['Normal']))
    elements.append(Paragraph(f'Свободных мест: {route.available_seats}', styles['Normal']))
    
    # Подписи
    elements.append(Spacer(1, 40))
    signature_data = [
        ['Водитель', '', 'Диспетчер', ''],
        ['_____________', 'подпись', '_____________', 'подпись']
    ]
    signature_table = Table(signature_data, colWidths=[4*cm, 4*cm, 4*cm, 4*cm])
    elements.append(signature_table)
    
    # Время генерации
    elements.append(Spacer(1, 20))
    elements.append(Paragraph(
        f'Документ сформирован: {timezone.now().strftime("%d.%m.%Y %H:%M")}',
        ParagraphStyle('Right', parent=styles['Normal'], alignment=2)
    ))
    
    # Генерируем PDF
    doc.build(elements)
    
    # Получаем значение из буфера
    pdf = buffer.getvalue()
    buffer.close()
    
    # Отправляем PDF
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="boarding_list_{route.id}.pdf"'
    response.write(pdf)
    
    return response

def generate_ticket_pdf(ticket):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    
    # Стили
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=16,
        spaceAfter=30,
        alignment=1
    )
    
    # Заголовок
    elements.append(Paragraph('Билет на автобус', title_style))
    elements.append(Spacer(1, 20))
    
    # Информация о билете
    ticket_info = [
        ['Номер билета:', str(ticket.id)],
        ['Маршрут:', f'{ticket.route.number}'],
        ['Откуда:', ticket.route.from_city],
        ['Куда:', ticket.route.to_city],
        ['Дата отправления:', ticket.route.departure_time.strftime('%d.%m.%Y')],
        ['Время отправления:', ticket.route.departure_time.strftime('%H:%M')],
        ['Место:', str(ticket.seat_number)],
        ['Стоимость:', f'{ticket.route.price} ₸'],
    ]
    
    # Таблица с информацией о билете
    ticket_table = Table(ticket_info, colWidths=[4*cm, 12*cm])
    ticket_table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(ticket_table)
    elements.append(Spacer(1, 20))
    
    # Информация о пассажире
    elements.append(Paragraph('Информация о пассажире', styles['Heading2']))
    passenger_info = [
        ['ФИО:', ticket.passenger_name],
        ['Документ:', ticket.passenger_document],
        ['Телефон:', ticket.passenger_phone],
    ]
    passenger_table = Table(passenger_info, colWidths=[4*cm, 12*cm])
    passenger_table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    elements.append(passenger_table)
    
    # Важная информация
    elements.append(Spacer(1, 20))
    elements.append(Paragraph('Важная информация:', styles['Heading2']))
    important_info = [
        '• Прибудьте на посадку за 30 минут до отправления',
        '• Имейте при себе документ, удостоверяющий личность',
        '• Сохраните билет до конца поездки',
    ]
    for info in important_info:
        elements.append(Paragraph(info, styles['Normal']))
    
    # Контактная информация
    elements.append(Spacer(1, 20))
    elements.append(Paragraph('Контактная информация:', styles['Heading2']))
    elements.append(Paragraph('Телефон: +7 (XXX) XXX-XX-XX', styles['Normal']))
    elements.append(Paragraph('Email: support@example.com', styles['Normal']))
    
    # Время генерации
    elements.append(Spacer(1, 30))
    elements.append(Paragraph(
        f'Билет сформирован: {timezone.now().strftime("%d.%m.%Y %H:%M")}',
        ParagraphStyle('Right', parent=styles['Normal'], alignment=2)
    ))
    
    # Генерируем PDF
    doc.build(elements)
    return buffer.getvalue()

def send_ticket_email(ticket):
    # Генерируем PDF билет
    pdf = generate_ticket_pdf(ticket)
    
    # Создаем email
    subject = f'Ваш билет на маршрут {ticket.route}'
    message = f'''
    Уважаемый(ая) {ticket.passenger_name}!
    
    Благодарим вас за покупку билета. Ваш билет во вложении.
    
    Информация о поездке:
    Маршрут: {ticket.route}
    Дата: {ticket.route.departure_time.strftime('%d.%m.%Y')}
    Время: {ticket.route.departure_time.strftime('%H:%M')}
    Место: {ticket.seat_number}
    
    Пожалуйста, сохраните билет и предъявите его при посадке.
    '''
    
    from django.core.mail import EmailMessage
    email = EmailMessage(
        subject,
        message,
        settings.DEFAULT_FROM_EMAIL,
        [ticket.user.email]
    )
    
    # Прикрепляем PDF
    email.attach(f'ticket_{ticket.id}.pdf', pdf, 'application/pdf')
    email.send()
