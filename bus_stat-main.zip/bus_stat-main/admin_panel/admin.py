from django.contrib import admin
from django.contrib.admin import AdminSite
from .models import Route, Ticket, Notification, BoardingList, FavoriteRoute

# Настройка админ-сайта
admin.site.site_header = "BusBook Administration"
admin.site.site_title = "BusBook Admin Portal"
admin.site.index_title = "Welcome to BusBook Admin Portal"

@admin.register(Route)
class RouteAdmin(admin.ModelAdmin):
    list_display = ('number', 'from_city', 'to_city', 'departure_time', 'arrival_time', 'price', 'available_seats', 'status')
    list_filter = ('from_city', 'to_city', 'status')
    search_fields = ('number', 'from_city', 'to_city', 'driver_name')
    ordering = ('departure_time',)

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ('route', 'seat_number', 'passenger_name', 'purchase_time', 'status')
    list_filter = ('status', 'route', 'purchase_time')
    search_fields = ('passenger_name', 'passenger_phone', 'passenger_document')
    ordering = ('purchase_time',)
    raw_id_fields = ('route', 'user')

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'type', 'created_at', 'is_read')
    list_filter = ('type', 'is_read', 'created_at')
    search_fields = ('user__username', 'message')
    ordering = ('-created_at',)

@admin.register(BoardingList)
class BoardingListAdmin(admin.ModelAdmin):
    list_display = ('route', 'created_at', 'total_passengers')
    list_filter = ('created_at',)
    search_fields = ('route__number', 'route__from_city', 'route__to_city')
    ordering = ('-created_at',)

@admin.register(FavoriteRoute)
class FavoriteRouteAdmin(admin.ModelAdmin):
    list_display = ('user', 'route', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'route__number')
    ordering = ('-created_at',)
